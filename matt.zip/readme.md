# Default Via keyboard for the Corne R2G by Mechboards UK

![r2g](https://cdn.shopify.com/s/files/1/0582/0242/3501/products/HelidoxCorneR2GPCB_1800x1800.png)

Corne R2G is an eddition of the classic CRKBD by footsan remade to feature a full smd assembly

In this fold can be found the default via enabled keymap that can be in conjunction 

Flash example for this Keymap:  
```sh
qmk flash -kb crkbd/r2g -km mb_via
```
